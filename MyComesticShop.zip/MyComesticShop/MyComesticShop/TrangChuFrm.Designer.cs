﻿
namespace MyComesticShop
{
    partial class TrangChuFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrangChuFrm));
            this.ssHomeFrm = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tssblCurrentTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.TChangeTime = new System.Windows.Forms.Timer(this.components);
            this.panelParent = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbtnDonHangMoi = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtnDonNhapMoi = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtnKho = new System.Windows.Forms.ToolStripDropDownButton();
            this.danhSáchTồnKhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sảnPhẩmMớiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.báoCáoTồnKhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtnKhuyenMai = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtnBaoCao = new System.Windows.Forms.ToolStripDropDownButton();
            this.nhậpHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bánHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbtnDangNhap = new System.Windows.Forms.ToolStripButton();
            this.tsbtnDangXuat = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsmiBtnThayDoiMK = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.msTrangChu = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PhanQuyentoolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.NewUser1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýTàiKhoảnNhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EmployeeRegistation1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DanhSachNVToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator29 = new System.Windows.Forms.ToolStripSeparator();
            this.LogoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đơnHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.taoĐonNhậpMớiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.sảnPhẩmKhoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.kháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kháchHàngTíchĐiểmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator28 = new System.Windows.Forms.ToolStripSeparator();
            this.danhSáchKháchHàngThànhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nhàCungCấpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NewSupplierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.danhSáchNhàCungCấpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.khuyếnMãiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AddMaKhuyenMaiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.danhSáchMãKhuyếnMãiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoNhậpHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.báoCáoBánHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchBánHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchNhậpHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ssHomeFrm.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.msTrangChu.SuspendLayout();
            this.SuspendLayout();
            // 
            // ssHomeFrm
            // 
            this.ssHomeFrm.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ssHomeFrm.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.tssblCurrentTime});
            this.ssHomeFrm.Location = new System.Drawing.Point(0, 759);
            this.ssHomeFrm.Name = "ssHomeFrm";
            this.ssHomeFrm.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.ssHomeFrm.Size = new System.Drawing.Size(1924, 26);
            this.ssHomeFrm.TabIndex = 0;
            this.ssHomeFrm.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(59, 20);
            this.toolStripStatusLabel1.Text = "Ready...";
            // 
            // tssblCurrentTime
            // 
            this.tssblCurrentTime.Name = "tssblCurrentTime";
            this.tssblCurrentTime.Size = new System.Drawing.Size(1845, 20);
            this.tssblCurrentTime.Spring = true;
            this.tssblCurrentTime.Text = "toolStripStatusLabel2";
            this.tssblCurrentTime.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TChangeTime
            // 
            this.TChangeTime.Tick += new System.EventHandler(this.TChangeTime_Tick);
            // 
            // panelParent
            // 
            this.panelParent.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panelParent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelParent.Enabled = false;
            this.panelParent.Location = new System.Drawing.Point(0, 0);
            this.panelParent.Margin = new System.Windows.Forms.Padding(4);
            this.panelParent.Name = "panelParent";
            this.panelParent.Size = new System.Drawing.Size(1924, 785);
            this.panelParent.TabIndex = 3;
            this.panelParent.Paint += new System.Windows.Forms.PaintEventHandler(this.panelParent_Paint);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.White;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnDonHangMoi,
            this.toolStripSeparator15,
            this.tsbtnDonNhapMoi,
            this.toolStripSeparator16,
            this.tsbtnKho,
            this.toolStripSeparator17,
            this.toolStripSeparator18,
            this.tsbtnKhuyenMai,
            this.toolStripSeparator20,
            this.tsbtnBaoCao,
            this.toolStripSeparator19,
            this.tsbtnDangNhap,
            this.tsbtnDangXuat});
            this.toolStrip1.Location = new System.Drawing.Point(0, 28);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1924, 59);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbtnDonHangMoi
            // 
            this.tsbtnDonHangMoi.Enabled = false;
            this.tsbtnDonHangMoi.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnDonHangMoi.Image")));
            this.tsbtnDonHangMoi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDonHangMoi.Name = "tsbtnDonHangMoi";
            this.tsbtnDonHangMoi.Size = new System.Drawing.Size(111, 56);
            this.tsbtnDonHangMoi.Text = "Đơn Hàng Mới";
            this.tsbtnDonHangMoi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 59);
            // 
            // tsbtnDonNhapMoi
            // 
            this.tsbtnDonNhapMoi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tsbtnDonNhapMoi.Enabled = false;
            this.tsbtnDonNhapMoi.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnDonNhapMoi.Image")));
            this.tsbtnDonNhapMoi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDonNhapMoi.Name = "tsbtnDonNhapMoi";
            this.tsbtnDonNhapMoi.Size = new System.Drawing.Size(115, 56);
            this.tsbtnDonNhapMoi.Text = "Đơn Nhập Mới ";
            this.tsbtnDonNhapMoi.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(6, 59);
            // 
            // tsbtnKho
            // 
            this.tsbtnKho.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.danhSáchTồnKhoToolStripMenuItem,
            this.sảnPhẩmMớiToolStripMenuItem,
            this.toolStripSeparator22,
            this.báoCáoTồnKhoToolStripMenuItem});
            this.tsbtnKho.Enabled = false;
            this.tsbtnKho.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnKho.Image")));
            this.tsbtnKho.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnKho.Name = "tsbtnKho";
            this.tsbtnKho.Size = new System.Drawing.Size(53, 56);
            this.tsbtnKho.Text = "Kho ";
            this.tsbtnKho.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // danhSáchTồnKhoToolStripMenuItem
            // 
            this.danhSáchTồnKhoToolStripMenuItem.Name = "danhSáchTồnKhoToolStripMenuItem";
            this.danhSáchTồnKhoToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.danhSáchTồnKhoToolStripMenuItem.Text = "Danh Sách Tồn Kho";
            // 
            // sảnPhẩmMớiToolStripMenuItem
            // 
            this.sảnPhẩmMớiToolStripMenuItem.Name = "sảnPhẩmMớiToolStripMenuItem";
            this.sảnPhẩmMớiToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.sảnPhẩmMớiToolStripMenuItem.Text = "Sản Phẩm Mới ";
            // 
            // toolStripSeparator22
            // 
            this.toolStripSeparator22.Name = "toolStripSeparator22";
            this.toolStripSeparator22.Size = new System.Drawing.Size(218, 6);
            // 
            // báoCáoTồnKhoToolStripMenuItem
            // 
            this.báoCáoTồnKhoToolStripMenuItem.Name = "báoCáoTồnKhoToolStripMenuItem";
            this.báoCáoTồnKhoToolStripMenuItem.Size = new System.Drawing.Size(221, 26);
            this.báoCáoTồnKhoToolStripMenuItem.Text = "Báo cáo Tồn Kho ";
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(6, 59);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(6, 59);
            // 
            // tsbtnKhuyenMai
            // 
            this.tsbtnKhuyenMai.Enabled = false;
            this.tsbtnKhuyenMai.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnKhuyenMai.Image")));
            this.tsbtnKhuyenMai.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnKhuyenMai.Name = "tsbtnKhuyenMai";
            this.tsbtnKhuyenMai.Size = new System.Drawing.Size(182, 56);
            this.tsbtnKhuyenMai.Text = "Chương Trình Khuyến Mãi";
            this.tsbtnKhuyenMai.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSeparator20
            // 
            this.toolStripSeparator20.Name = "toolStripSeparator20";
            this.toolStripSeparator20.Size = new System.Drawing.Size(6, 59);
            // 
            // tsbtnBaoCao
            // 
            this.tsbtnBaoCao.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nhậpHàngToolStripMenuItem,
            this.bánHàngToolStripMenuItem});
            this.tsbtnBaoCao.Enabled = false;
            this.tsbtnBaoCao.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnBaoCao.Image")));
            this.tsbtnBaoCao.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnBaoCao.Name = "tsbtnBaoCao";
            this.tsbtnBaoCao.Size = new System.Drawing.Size(83, 56);
            this.tsbtnBaoCao.Text = "Báo Cáo ";
            this.tsbtnBaoCao.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // nhậpHàngToolStripMenuItem
            // 
            this.nhậpHàngToolStripMenuItem.Name = "nhậpHàngToolStripMenuItem";
            this.nhậpHàngToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.nhậpHàngToolStripMenuItem.Text = "Nhập hàng";
            // 
            // bánHàngToolStripMenuItem
            // 
            this.bánHàngToolStripMenuItem.Name = "bánHàngToolStripMenuItem";
            this.bánHàngToolStripMenuItem.Size = new System.Drawing.Size(165, 26);
            this.bánHàngToolStripMenuItem.Text = "Bán hàng";
            // 
            // toolStripSeparator19
            // 
            this.toolStripSeparator19.Name = "toolStripSeparator19";
            this.toolStripSeparator19.Size = new System.Drawing.Size(6, 59);
            // 
            // tsbtnDangNhap
            // 
            this.tsbtnDangNhap.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsbtnDangNhap.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnDangNhap.Image")));
            this.tsbtnDangNhap.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDangNhap.Name = "tsbtnDangNhap";
            this.tsbtnDangNhap.Size = new System.Drawing.Size(86, 56);
            this.tsbtnDangNhap.Text = "Đăng nhập";
            this.tsbtnDangNhap.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnDangNhap.Click += new System.EventHandler(this.toolStripbtnDangNhap_Click);
            // 
            // tsbtnDangXuat
            // 
            this.tsbtnDangXuat.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tsbtnDangXuat.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiBtnThayDoiMK,
            this.đăngXuấtToolStripMenuItem});
            this.tsbtnDangXuat.Image = ((System.Drawing.Image)(resources.GetObject("tsbtnDangXuat.Image")));
            this.tsbtnDangXuat.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnDangXuat.Name = "tsbtnDangXuat";
            this.tsbtnDangXuat.Size = new System.Drawing.Size(91, 56);
            this.tsbtnDangXuat.Text = "Đăng xuất";
            this.tsbtnDangXuat.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tsbtnDangXuat.Visible = false;
            this.tsbtnDangXuat.Click += new System.EventHandler(this.tsbtnDangXuat_Click);
            // 
            // tsmiBtnThayDoiMK
            // 
            this.tsmiBtnThayDoiMK.Name = "tsmiBtnThayDoiMK";
            this.tsmiBtnThayDoiMK.Size = new System.Drawing.Size(214, 26);
            this.tsmiBtnThayDoiMK.Text = "Thay đổi mật khẩu";
            this.tsmiBtnThayDoiMK.Click += new System.EventHandler(this.tsmiBtnThayDoiMK_Click);
            // 
            // đăngXuấtToolStripMenuItem
            // 
            this.đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
            this.đăngXuấtToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.đăngXuấtToolStripMenuItem.Text = "Đăng xuất";
            this.đăngXuấtToolStripMenuItem.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem_Click);
            // 
            // msTrangChu
            // 
            this.msTrangChu.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.msTrangChu.Enabled = false;
            this.msTrangChu.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.msTrangChu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.đơnHàngToolStripMenuItem,
            this.toolStripMenuItem15,
            this.sảnPhẩmKhoToolStripMenuItem,
            this.kháchHàngToolStripMenuItem,
            this.nhàCungCấpToolStripMenuItem,
            this.khuyếnMãiToolStripMenuItem,
            this.báoCáoToolStripMenuItem});
            this.msTrangChu.Location = new System.Drawing.Point(0, 0);
            this.msTrangChu.Name = "msTrangChu";
            this.msTrangChu.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.msTrangChu.Size = new System.Drawing.Size(1924, 28);
            this.msTrangChu.TabIndex = 1;
            this.msTrangChu.Text = "menuStrip1";
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PhanQuyentoolStripMenuItem1,
            this.toolStripMenuItem1,
            this.quảnLýTàiKhoảnNhânViênToolStripMenuItem,
            this.toolStripSeparator29,
            this.LogoutToolStripMenuItem,
            this.ExitToolStripMenuItem});
            this.hệThốngToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(92, 24);
            this.hệThốngToolStripMenuItem.Text = "Hệ Thống ";
            this.hệThốngToolStripMenuItem.Click += new System.EventHandler(this.hệThốngToolStripMenuItem_Click);
            // 
            // PhanQuyentoolStripMenuItem1
            // 
            this.PhanQuyentoolStripMenuItem1.Name = "PhanQuyentoolStripMenuItem1";
            this.PhanQuyentoolStripMenuItem1.Size = new System.Drawing.Size(284, 26);
            this.PhanQuyentoolStripMenuItem1.Text = "Phân Quyền Người Dùng";
            this.PhanQuyentoolStripMenuItem1.Click += new System.EventHandler(this.PhanQuyentoolStripMenuItem1_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NewUser1ToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(284, 26);
            this.toolStripMenuItem1.Text = "Tài Khoản";
            // 
            // NewUser1ToolStripMenuItem
            // 
            this.NewUser1ToolStripMenuItem.Name = "NewUser1ToolStripMenuItem";
            this.NewUser1ToolStripMenuItem.Size = new System.Drawing.Size(190, 26);
            this.NewUser1ToolStripMenuItem.Text = "Tài Khoản Mới ";
            this.NewUser1ToolStripMenuItem.Click += new System.EventHandler(this.NewUser1ToolStripMenuItem_Click);
            // 
            // quảnLýTàiKhoảnNhânViênToolStripMenuItem
            // 
            this.quảnLýTàiKhoảnNhânViênToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EmployeeRegistation1ToolStripMenuItem,
            this.DanhSachNVToolStripMenuItem1});
            this.quảnLýTàiKhoảnNhânViênToolStripMenuItem.Name = "quảnLýTàiKhoảnNhânViênToolStripMenuItem";
            this.quảnLýTàiKhoảnNhânViênToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.quảnLýTàiKhoảnNhânViênToolStripMenuItem.Text = "Quản Lý Tài Khoản Nhân Viên";
            // 
            // EmployeeRegistation1ToolStripMenuItem
            // 
            this.EmployeeRegistation1ToolStripMenuItem.Name = "EmployeeRegistation1ToolStripMenuItem";
            this.EmployeeRegistation1ToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.EmployeeRegistation1ToolStripMenuItem.Text = "Đăng Ký Nhân Viên ";
            this.EmployeeRegistation1ToolStripMenuItem.Click += new System.EventHandler(this.EmployeeRegistation1ToolStripMenuItem_Click);
            // 
            // DanhSachNVToolStripMenuItem1
            // 
            this.DanhSachNVToolStripMenuItem1.Name = "DanhSachNVToolStripMenuItem1";
            this.DanhSachNVToolStripMenuItem1.Size = new System.Drawing.Size(234, 26);
            this.DanhSachNVToolStripMenuItem1.Text = "Danh Sách Nhân Viên";
            this.DanhSachNVToolStripMenuItem1.Click += new System.EventHandler(this.DanhSachNVToolStripMenuItem1_Click);
            // 
            // toolStripSeparator29
            // 
            this.toolStripSeparator29.Name = "toolStripSeparator29";
            this.toolStripSeparator29.Size = new System.Drawing.Size(281, 6);
            // 
            // LogoutToolStripMenuItem
            // 
            this.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem";
            this.LogoutToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.LogoutToolStripMenuItem.Text = "Đăng xuất";
            this.LogoutToolStripMenuItem.Click += new System.EventHandler(this.LogoutToolStripMenuItem_Click);
            // 
            // ExitToolStripMenuItem
            // 
            this.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem";
            this.ExitToolStripMenuItem.Size = new System.Drawing.Size(284, 26);
            this.ExitToolStripMenuItem.Text = "Thoát";
            this.ExitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItem_Click);
            // 
            // đơnHàngToolStripMenuItem
            // 
            this.đơnHàngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.taoĐonNhậpMớiToolStripMenuItem,
            this.toolStripSeparator1,
            this.danhSáchBánHàngToolStripMenuItem});
            this.đơnHàngToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.đơnHàngToolStripMenuItem.Name = "đơnHàngToolStripMenuItem";
            this.đơnHàngToolStripMenuItem.Size = new System.Drawing.Size(88, 24);
            this.đơnHàngToolStripMenuItem.Text = "Bán Hàng";
            // 
            // taoĐonNhậpMớiToolStripMenuItem
            // 
            this.taoĐonNhậpMớiToolStripMenuItem.Name = "taoĐonNhậpMớiToolStripMenuItem";
            this.taoĐonNhậpMớiToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.taoĐonNhậpMớiToolStripMenuItem.Text = "Tạo Đơn Hàng";
            this.taoĐonNhậpMớiToolStripMenuItem.Click += new System.EventHandler(this.taoĐonNhậpMớiToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(228, 6);
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem16,
            this.toolStripSeparator10,
            this.danhSáchNhậpHàngToolStripMenuItem});
            this.toolStripMenuItem15.ForeColor = System.Drawing.Color.White;
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(99, 24);
            this.toolStripMenuItem15.Text = "Nhập Hàng";
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(242, 26);
            this.toolStripMenuItem16.Text = "Tạo Đơn Nhập Hàng";
            this.toolStripMenuItem16.Click += new System.EventHandler(this.tạoĐơnNhậpHàngToolStripMenuItem_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(239, 6);
            // 
            // sảnPhẩmKhoToolStripMenuItem
            // 
            this.sảnPhẩmKhoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýSảnPhẩmToolStripMenuItem,
            this.toolStripSeparator5});
            this.sảnPhẩmKhoToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.sảnPhẩmKhoToolStripMenuItem.Name = "sảnPhẩmKhoToolStripMenuItem";
            this.sảnPhẩmKhoToolStripMenuItem.Size = new System.Drawing.Size(142, 24);
            this.sảnPhẩmKhoToolStripMenuItem.Text = "Kho Và Sản Phẩm ";
            this.sảnPhẩmKhoToolStripMenuItem.Click += new System.EventHandler(this.sảnPhẩmKhoToolStripMenuItem_Click);
            // 
            // quảnLýSảnPhẩmToolStripMenuItem
            // 
            this.quảnLýSảnPhẩmToolStripMenuItem.Name = "quảnLýSảnPhẩmToolStripMenuItem";
            this.quảnLýSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.quảnLýSảnPhẩmToolStripMenuItem.Text = "Quản Lý Sản Phẩm";
            this.quảnLýSảnPhẩmToolStripMenuItem.Click += new System.EventHandler(this.quảnLýSảnPhẩmToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(221, 6);
            // 
            // kháchHàngToolStripMenuItem
            // 
            this.kháchHàngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kháchHàngTíchĐiểmToolStripMenuItem,
            this.toolStripSeparator28,
            this.danhSáchKháchHàngThànhViênToolStripMenuItem});
            this.kháchHàngToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.kháchHàngToolStripMenuItem.Name = "kháchHàngToolStripMenuItem";
            this.kháchHàngToolStripMenuItem.Size = new System.Drawing.Size(103, 24);
            this.kháchHàngToolStripMenuItem.Text = "Khách Hàng";
            // 
            // kháchHàngTíchĐiểmToolStripMenuItem
            // 
            this.kháchHàngTíchĐiểmToolStripMenuItem.Name = "kháchHàngTíchĐiểmToolStripMenuItem";
            this.kháchHàngTíchĐiểmToolStripMenuItem.Size = new System.Drawing.Size(246, 26);
            this.kháchHàngTíchĐiểmToolStripMenuItem.Text = "Khách hàng mới";
            this.kháchHàngTíchĐiểmToolStripMenuItem.Click += new System.EventHandler(this.kháchHàngTíchĐiểmToolStripMenuItem_Click);
            // 
            // toolStripSeparator28
            // 
            this.toolStripSeparator28.Name = "toolStripSeparator28";
            this.toolStripSeparator28.Size = new System.Drawing.Size(243, 6);
            // 
            // danhSáchKháchHàngThànhViênToolStripMenuItem
            // 
            this.danhSáchKháchHàngThànhViênToolStripMenuItem.Name = "danhSáchKháchHàngThànhViênToolStripMenuItem";
            this.danhSáchKháchHàngThànhViênToolStripMenuItem.Size = new System.Drawing.Size(246, 26);
            this.danhSáchKháchHàngThànhViênToolStripMenuItem.Text = "Danh Sách Khách Hàng";
            this.danhSáchKháchHàngThànhViênToolStripMenuItem.Click += new System.EventHandler(this.danhSáchKháchHàngThànhViênToolStripMenuItem_Click);
            // 
            // nhàCungCấpToolStripMenuItem
            // 
            this.nhàCungCấpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NewSupplierToolStripMenuItem,
            this.toolStripSeparator4,
            this.danhSáchNhàCungCấpToolStripMenuItem,
            this.toolStripSeparator3});
            this.nhàCungCấpToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.nhàCungCấpToolStripMenuItem.Name = "nhàCungCấpToolStripMenuItem";
            this.nhàCungCấpToolStripMenuItem.Size = new System.Drawing.Size(118, 24);
            this.nhàCungCấpToolStripMenuItem.Text = "Nhà Cung Cấp";
            // 
            // NewSupplierToolStripMenuItem
            // 
            this.NewSupplierToolStripMenuItem.Name = "NewSupplierToolStripMenuItem";
            this.NewSupplierToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.NewSupplierToolStripMenuItem.Text = "Thêm Nhà Cung Cấp";
            this.NewSupplierToolStripMenuItem.Click += new System.EventHandler(this.NewSupplierToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(258, 6);
            // 
            // danhSáchNhàCungCấpToolStripMenuItem
            // 
            this.danhSáchNhàCungCấpToolStripMenuItem.Name = "danhSáchNhàCungCấpToolStripMenuItem";
            this.danhSáchNhàCungCấpToolStripMenuItem.Size = new System.Drawing.Size(261, 26);
            this.danhSáchNhàCungCấpToolStripMenuItem.Text = "\tDanh Sách Nhà Cung Cấp";
            this.danhSáchNhàCungCấpToolStripMenuItem.Click += new System.EventHandler(this.danhSáchNhàCungCấpToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(258, 6);
            // 
            // khuyếnMãiToolStripMenuItem
            // 
            this.khuyếnMãiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddMaKhuyenMaiToolStripMenuItem,
            this.toolStripSeparator6,
            this.danhSáchMãKhuyếnMãiToolStripMenuItem});
            this.khuyếnMãiToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.khuyếnMãiToolStripMenuItem.Name = "khuyếnMãiToolStripMenuItem";
            this.khuyếnMãiToolStripMenuItem.Size = new System.Drawing.Size(100, 24);
            this.khuyếnMãiToolStripMenuItem.Text = "Khuyến Mãi";
            this.khuyếnMãiToolStripMenuItem.Click += new System.EventHandler(this.khuyếnMãiToolStripMenuItem_Click);
            // 
            // AddMaKhuyenMaiToolStripMenuItem
            // 
            this.AddMaKhuyenMaiToolStripMenuItem.Name = "AddMaKhuyenMaiToolStripMenuItem";
            this.AddMaKhuyenMaiToolStripMenuItem.Size = new System.Drawing.Size(268, 26);
            this.AddMaKhuyenMaiToolStripMenuItem.Text = "Thêm Mã Khuyến Mãi";
            this.AddMaKhuyenMaiToolStripMenuItem.Click += new System.EventHandler(this.AddMaKhuyenMaiToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(265, 6);
            // 
            // danhSáchMãKhuyếnMãiToolStripMenuItem
            // 
            this.danhSáchMãKhuyếnMãiToolStripMenuItem.Name = "danhSáchMãKhuyếnMãiToolStripMenuItem";
            this.danhSáchMãKhuyếnMãiToolStripMenuItem.Size = new System.Drawing.Size(268, 26);
            this.danhSáchMãKhuyếnMãiToolStripMenuItem.Text = "Danh Sách Mã Khuyến Mãi";
            this.danhSáchMãKhuyếnMãiToolStripMenuItem.Click += new System.EventHandler(this.danhSáchMãKhuyếnMãiToolStripMenuItem_Click);
            // 
            // báoCáoToolStripMenuItem
            // 
            this.báoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.báoCáoNhậpHàngToolStripMenuItem,
            this.báoCáoBánHàngToolStripMenuItem});
            this.báoCáoToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.báoCáoToolStripMenuItem.Name = "báoCáoToolStripMenuItem";
            this.báoCáoToolStripMenuItem.Size = new System.Drawing.Size(79, 24);
            this.báoCáoToolStripMenuItem.Text = "Báo Cáo";
            // 
            // báoCáoNhậpHàngToolStripMenuItem
            // 
            this.báoCáoNhậpHàngToolStripMenuItem.Name = "báoCáoNhậpHàngToolStripMenuItem";
            this.báoCáoNhậpHàngToolStripMenuItem.Size = new System.Drawing.Size(228, 26);
            this.báoCáoNhậpHàngToolStripMenuItem.Text = "Báo Cáo Nhập Hàng";
            this.báoCáoNhậpHàngToolStripMenuItem.Click += new System.EventHandler(this.báoCáoNhậpHàngToolStripMenuItem_Click_1);
            // 
            // báoCáoBánHàngToolStripMenuItem
            // 
            this.báoCáoBánHàngToolStripMenuItem.Name = "báoCáoBánHàngToolStripMenuItem";
            this.báoCáoBánHàngToolStripMenuItem.Size = new System.Drawing.Size(228, 26);
            this.báoCáoBánHàngToolStripMenuItem.Text = "Báo Cáo Bán Hàng";
            this.báoCáoBánHàngToolStripMenuItem.Click += new System.EventHandler(this.báoCáoBánHàngToolStripMenuItem_Click_1);
            // 
            // danhSáchBánHàngToolStripMenuItem
            // 
            this.danhSáchBánHàngToolStripMenuItem.Name = "danhSáchBánHàngToolStripMenuItem";
            this.danhSáchBánHàngToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.danhSáchBánHàngToolStripMenuItem.Text = "Danh Sách Bán Hàng";
            this.danhSáchBánHàngToolStripMenuItem.Click += new System.EventHandler(this.danhSáchBánHàngToolStripMenuItem_Click);
            // 
            // danhSáchNhậpHàngToolStripMenuItem
            // 
            this.danhSáchNhậpHàngToolStripMenuItem.Name = "danhSáchNhậpHàngToolStripMenuItem";
            this.danhSáchNhậpHàngToolStripMenuItem.Size = new System.Drawing.Size(242, 26);
            this.danhSáchNhậpHàngToolStripMenuItem.Text = "Danh Sách Nhập Hàng";
            this.danhSáchNhậpHàngToolStripMenuItem.Click += new System.EventHandler(this.danhSáchNhậpHàngToolStripMenuItem_Click);
            // 
            // TrangChuFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightCyan;
            this.ClientSize = new System.Drawing.Size(1924, 785);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.ssHomeFrm);
            this.Controls.Add(this.msTrangChu);
            this.Controls.Add(this.panelParent);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.msTrangChu;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "TrangChuFrm";
            this.Text = "Cosmetics Store ";
            this.Load += new System.EventHandler(this.TrangChuFrm_Load);
            this.ssHomeFrm.ResumeLayout(false);
            this.ssHomeFrm.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.msTrangChu.ResumeLayout(false);
            this.msTrangChu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip ssHomeFrm;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel tssblCurrentTime;
        private System.Windows.Forms.MenuStrip msTrangChu;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbtnDonHangMoi;
        private System.Windows.Forms.ToolStripButton tsbtnDonNhapMoi;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.ToolStripButton tsbtnKhuyenMai;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator20;
        private System.Windows.Forms.ToolStripDropDownButton tsbtnKho;
        private System.Windows.Forms.ToolStripMenuItem danhSáchTồnKhoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sảnPhẩmMớiToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator22;
        private System.Windows.Forms.ToolStripMenuItem báoCáoTồnKhoToolStripMenuItem;
        private System.Windows.Forms.Panel panelParent;
        private System.Windows.Forms.Timer TChangeTime;
        private System.Windows.Forms.ToolStripDropDownButton tsbtnDangXuat;
        private System.Windows.Forms.ToolStripMenuItem tsmiBtnThayDoiMK;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton tsbtnDangNhap;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem PhanQuyentoolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem NewUser1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýTàiKhoảnNhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EmployeeRegistation1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DanhSachNVToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator29;
        private System.Windows.Forms.ToolStripMenuItem LogoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ExitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đơnHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem taoĐonNhậpMớiToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem sảnPhẩmKhoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýSảnPhẩmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kháchHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kháchHàngTíchĐiểmToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator28;
        private System.Windows.Forms.ToolStripMenuItem danhSáchKháchHàngThànhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nhàCungCấpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem NewSupplierToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem danhSáchNhàCungCấpToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem khuyếnMãiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AddMaKhuyenMaiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripDropDownButton tsbtnBaoCao;
        private System.Windows.Forms.ToolStripMenuItem nhậpHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bánHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator19;
        private System.Windows.Forms.ToolStripMenuItem báoCáoNhậpHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem báoCáoBánHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem danhSáchMãKhuyếnMãiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchBánHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchNhậpHàngToolStripMenuItem;
    }
}