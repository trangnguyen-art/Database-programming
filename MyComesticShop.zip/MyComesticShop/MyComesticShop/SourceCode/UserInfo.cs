﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComesticShop.SourceCode
{
    public class UserInfo
    {
        //    public int id_taikhoan { get; set; }
        //    public int id_phan_quyen { get; set; }
        //    public string email { get; set; }
        //    public string mat_khau { get; set; }

        public static int id_taikhoan { get; set; }
        public static int id_phan_quyen { get; set; }
        public static string email { get; set; }
        public static string mat_khau { get; set; }
        public static int EmployeeID { get; set; }

        public static int ten_dang_nhap { get; set; }
        public static int ho_ten { get; set; }

        public static int id_san_pham { get; set; }

    }
}
